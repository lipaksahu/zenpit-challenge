import React, {Component} from 'react';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom';
import Phones from '../components/Phones';
import NotFoundPage from '../components/NotFoundPage';

const AppRouter = ()=> (
    <Router>
        <div>
            <Switch>
                <Route path="/" component={Phones} exact={true} />
                <Route component={NotFoundPage}/>
            </Switch>
        </div>
    </Router>
);

export default AppRouter;
