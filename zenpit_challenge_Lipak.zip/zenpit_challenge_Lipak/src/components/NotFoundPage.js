import React from 'react';
import {Link} from 'react-router-dom';

const NotFoundPage = () => (
    <div className="not-found-page">
        <h3>Sorry ! This page doesn't exist. Go to <Link to="/">Home</Link></h3>
    </div>
);

export default NotFoundPage;