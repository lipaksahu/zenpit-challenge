import React, {Component} from 'react';
import Phone from './Phone';

import { Layout, Menu, Icon, Spin, AutoComplete } from 'antd';
const { Content, Footer, Sider, Header } = Layout;
const SubMenu = Menu.SubMenu;
const token = '429cdaf8ead6a3a565c72111d444074ead75b2f0862c01ac';


export default class Phones extends Component {

    constructor(props){
        super(props);
        this.state = {
            phones: [],
            isLoaded: false,
            filteredPhones: [],
            collapsed: false,
            logoSize: '14px',
            dataSource :[],
            filterKey: 'BY_SCORE_ASC'
        };
        this.searchPhoneParent =  this.searchPhoneParent.bind(this);
        this.handleSort = this.handleSort.bind(this);
    }

    onCollapse = (collapsed) => {
        this.setState({ collapsed });
    };

    componentDidMount(){
        const autoCompleteData = [];

        fetch(`https://fonoapi.freshpixl.com/v1/getlatest?token=${token}`)
            .then(response => response.json())
            .then(phones => {
                phones.map(phone => {
                    autoCompleteData.push(phone.DeviceName);
                });
                this.setState({
                    phones,
                    isLoaded:true,
                    dataSource:autoCompleteData
                })
            });
    }

    searchPhoneParent(value){
        console.log("Search value", value);
        const filteredPhones = this.state.phones.filter(phone => {
            if(phone.DeviceName.toUpperCase().indexOf(value.toUpperCase()) !== -1){
                return phone
            }
        });
        this.setState({filteredPhones});
    }

    handleSort(){
        const {filterKey, phones} = this.state;
        var filteredList;
        if(filterKey === 'BY_SCORE_DEC'){
            filteredList = phones.sort(
                (a,b) => {
                    if(b.DeviceName < a.DeviceName){
                        return -1;
                    }
                }
            );
        }else if(filterKey === 'BY_SCORE_ASC'){
            filteredList = phones.sort(
                (a,b) => {
                    if(a.DeviceName > b.DeviceName){
                        return 1;
                    }
                }
            );
        }
        this.setState({phones:filteredList})
    }

    render(){
        return(
            <Layout style={{ minHeight: '100vh' }}>
                <Sider
                    breakpoint="md"
                    collapsedWidth="0"
                    collapsed={this.state.collapsed}
                    onCollapse={this.onCollapse}
                >
                    <div className="logo" style={{fontSize : this.state.collapsed ? this.state.logoSize : ''}}>
                        Phones App
                    </div>
                    <Menu theme="dark" defaultSelectedKeys={['1']} mode="inline" style={{margin: '40px 0 0'}}>
                        <SubMenu
                            key="sub1"
                            title={<span><Icon type="search" /><span>Sort By</span></span>}
                        >
                            <Menu.Item key="3" onClick={() => this.setState({ filterKey: 'BY_SCORE_ASC' }, this.handleSort)}>Brand Asc</Menu.Item>
                            <Menu.Item key="4" onClick={() => this.setState({ filterKey: 'BY_SCORE_DEC' }, this.handleSort)}>Brand Dsc</Menu.Item>
                        </SubMenu>
                    </Menu>
                </Sider>
                <Layout>
                    <AutoComplete
                        style={{ width: 350, padding: 10, left: '67%' }}
                        dataSource={this.state.dataSource}
                        placeholder="Search phone here.."
                        filterOption={(inputValue, option) => option.props.children.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1}
                        onChange={this.searchPhoneParent}
                    />
                    <Content style={{ margin: '0 16px', background: "#fff", padding: "20px" }}>
                        {this.state.isLoaded ? null : <Spin className="loader-spin"/>}
                        {
                            this.state.filteredPhones.length > 0 ?
                                this.state.filteredPhones.map((phone,i) => (
                                    <Phone phone={phone} key={i}/>
                                )) :
                                this.state.phones.map((phone,i) => (
                                    <Phone phone={phone} key={i}/>
                                ))
                        }
                    </Content>
                    <Footer style={{ textAlign: 'center' }}>
                        All Rights Reserved. © Zenpit Pvt. Ltd. 2018
                    </Footer>
                </Layout>
            </Layout>
        )
    }
}
