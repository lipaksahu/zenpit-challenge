import React from 'react';
import { Card, Col, Row } from 'antd';

const Phone = (props) => {
    const {DeviceName, Brand, os, price, announced, weight, radio} = props.phone;
    return (
        <div style={{ background: '#ECECEC' }}>
            <Card title={DeviceName} bordered={false} style={{ background: 'rgba(238, 238, 238, 0.32)', width: '24%', float: 'left', margin: '5px' }}>
                <p><b>Brand :</b> {Brand}</p>
                <p><b>Weight :</b> {weight}</p>
                <p><b>Announced :</b> {announced}</p>
                <p><b>Speed :</b> {radio}</p>
                <p><b>Price :</b> {price}</p>
            </Card>
        </div>
    )
};

export default Phone;
